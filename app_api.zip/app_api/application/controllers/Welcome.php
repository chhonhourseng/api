<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		$this->load->view('welcome_message');
	}
	function get_folder(){
		$this->load->helper('directory');
		$map = directory_map('../application/views/theme/',1);
		header("Content-Type: application/json");
		//echo json_encode($map);
		//asort($map);
		foreach($map as $file){
		    if(is_string($file)){
		        echo $file;
		    }
		}
	}
	function upload(){
		// $url = 'http://www.payment.cool-systemlogistics.com/dist/background.png';
		// /* Extract the filename */
		// echo getcwd();
		// $filename = substr($url, strrpos($url, '/') + 1);
		// /* Save file wherever you want */
		// file_put_contents('upload/'.$filename, file_get_contents($url));
		// $ch = curl_init('http://www.payment.cool-systemlogistics.com/dist/background.png');
		// $fp = fopen('upload/flower.gif', 'wb');
		// curl_setopt($ch, CURLOPT_FILE, $fp);
		// curl_setopt($ch, CURLOPT_HEADER, 0);
		// curl_exec($ch);
		// curl_close($ch);
		// fclose($fp);
		copy('http://somedomain.com/file.jpeg', 'uploadss/file.jpeg');
	}
}
