<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		echo '<h1> Home </h1>';
		$s = "sdf";
		
	}
	function homes(){
	$ip = $this->input->ip_address();
    $geo_data = get_geolocation($ip);

    echo "Country code : ".$geo_data['country_name']."\n";
    echo "Country name : ".$geo_data['city']."\n";
	}
	function get_geolocation($ip) {
        // $d = file_get_contents&#40;"http://www.ipinfodb.com/ip_query.php?ip=$ip&output=xml"&#41;;

        // //Use backup server if cannot make a connection
        // if ($d!='') {
        //     $backup = file_get_contents&#40;"http://backup.ipinfodb.com/ip_query.php?ip=$ip&output=xml"&#41;;
        //     $result = new SimpleXMLElement($backup);
        //     if (!$backup)
        //         return false; // Failed to open connection
        // } else {
        //     $result = new SimpleXMLElement($d);
        // }
        // //Return the data as an array
        // return array('ip'=>$ip, 'country_code'=>$result->CountryCode, 'country_name'=>$result->CountryName, 'region_name'=>$result->RegionName, 'city'=>$result->City, 'zip_postal_code'=>$result->ZipPostalCode, 'latitude'=>$result->Latitude, 'longitude'=>$result->Longitude, 'timezone'=>$result->Timezone, 'gmtoffset'=>$result->Gmtoffset, 'dstoffset'=>$result->Dstoffset);
    }
}
